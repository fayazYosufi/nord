'use client'
import React from 'react'
const Logo = () => {
  return (
    <div style={{width:'142px'}}>
        <div className='dFlex jcsb alic'>
            <div className=' bold' style={{fontSize:'30px' , padding:'5px 0'  }}>
                <div className="jdkfj" style={{borderRight:'2px solid', paddingRight:'10px', fontSize:'3rem !imoprtant'}}>SEO</div>
            </div>
            <div className='fs12 bold cGray'>
              <div>NORD</div>
              <div>GMBH</div>
            </div>
        </div>
        <div className='oneLine' style={{fontSize:'6.8px'}}>SECURITY EVENT & PROPERTY PROTECTION</div>
    </div>
  )
}

export default Logo